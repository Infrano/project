<?php include('../connection/connect.php'); 
session_start();
?>


<?php

    $id = $_GET['id'];

     $semail= $_SESSION['student_email'];
     $spass = $_SESSION['student_pass'];
     $sgroup = $_SESSION['MM_UserGroup_students'];

     $sql = mysqli_query($conn,"SELECT * FROM `student_details` WHERE email = '$semail' AND pass = '$spass' ");
     $row= mysqli_fetch_array($sql);
    

    if((!isset($semail)) || (!isset($spass)) || (!$row))
    {
        echo " <script>alert('Something went wrong.')</script>";
        echo " <script>location='../login.php' </script>";
    }



$sql = mysqli_query($conn,"SELECT * FROM `student_details` WHERE id = '$id' ");
$row = mysqli_fetch_array($sql);

if( $row['id_status'] == 0 || $row['id_status'] == '' ){

    echo "<script>alert('Id Card not yet alloted , Please contact college for more details .')</script>";
    echo "<script>location='student-index.php'</script>";

}



?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Student Id Card</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../css/student.css">
<style>
      .id-section{
        background-image: url('img/bg-id.jpg');
        background-repeat: no-repeat;
        background-size: cover;
        background-position: center;
        padding:10px;
  }
</style>
</head>
<body>


<!-- navbar -->
<div class="navbar">
  <a href="#" class="logo"><img src="img/Logo.png" alt="" width="40" ></a>
  <a href="index.php" class="logo-text">Techno Collage of Engineering Agartala</a>
  
  <a  href="logout.php" class="right" onclick="return confirm('Are you sure?')">Logout</a>
  <a href="student-idcard.php?id=<?php echo $row['id']; ?>" class="right">View Id Card</a>
  <a href="admit-card.php?id=<?php echo $row['id']; ?>"  class="right">View Admit Card</a>
  
  <a href="student-index.php" class="right">Home</a>
</div>
<!-- navbar -->


<div class="description-section">
    
    <div class="id-section">
        <div style="display: flex;">
            <div style="width: 15%;">
                <div style="margin: auto;text-align: right;">
                    <img src="img/Logo.png" style="width: 120px;" alt="">
                </div>
            </div>
    
            <div class="text-center"  style="width: 85%;">
                <div style=" margin-left: -260px;">
                    <h1 style="margin: 0;">Techo College of Engineering Agartala</h1>
                    <p style="color: #e2261d; text-align: center;"> ( A Degree Engineering College affiliated to Tripura University,approved by AICTE )</p>
                    <p style="text-align: center;">Maheshkhola, Anandanagar, Agartala, West Tripura</p>
                </div>
            </div>
        </div>

        <div style="display: flex;padding: 50px;">
            <div style="width: 70%;">

                <?php 

                $dob = $row['dob'];
                
                $dob_converted = date('d / m / Y', strtotime($dob));
                
                ?>
                <h4><b><span>STUDENT ID :</span> &nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;    <?php if($row['student_id']) {echo $row['student_id'];}  ?></b></h4>
                <h4><b>STUDENT NAME :&nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;   <?php echo $row['name']; ?></b></h4>
                <h4><b>BLOOD GROUP :&nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;   <?php if($row['blood_group']) {echo $row['blood_group'];}  ?></b></h4>
                <h4><b>DATE OF BIRTH :&nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;   <?php echo $dob_converted ; ?></b></h4>
                <h4><b>FATHER'S NAME : &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  <?php echo $row['father_name']; ?></b></h4>
                <h4><b>BRANCH :&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;   <?php echo $row['branch']; ?></b></h4>
                <h4><b>SEMESTER ADMITED :&nbsp;&nbsp;&nbsp;  <?php echo $row['sem_admitted']; ?></b></h4>
                <!-- <h4><b>ADMISSION SESSION :&nbsp;&nbsp;&nbsp;  <?php echo $row['sem_admitted']; ?></b></h4> -->

               
            </div>

            <div style="width: 30%; margin: auto;text-align: center;">

                <?php if($row['image']){  ?>

                    <img src="../<?php echo $row['image'] ?>" style="max-width:100%;border-radius:4px;" alt="">

                <?php }else{?>

                    <img src="img/blank.webp" width="350px" alt="">

                <?php  } ?>



            </div>

        </div>

        <div style="display: flex;padding: 40px 50px;">
            <div style="width: 33%;">
                <div class="text-center">
                    <h4 style="margin-top: 20px;">Authorised Signatory</h4>
                </div>
            </div>
            <div style="width: 33%;">
                <div class="text-center">
                    <h5 style="margin: 0;">Website : www.tiaedu.org</h5>
                    <h5 style="margin: 2px;">Contact No. +919774810480 </h5>
                </div>
            </div>

            <div style="width: 33%;">
                <div class="text-center">
                    <h4 style="margin-top: 20px;">Valid till : <?php echo $row['valid_start'] ?> - <?php echo $row['valid_end'] ?> </h4>
                </div>
            </div>
        </div>
    </div>
</div>




<?php include('../footer.php'); ?>