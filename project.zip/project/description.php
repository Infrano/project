<?php include('header.php'); ?>




<div class="description-section" style="height:600px;">
    <h1>Description of ID card & Admit card generations</h1>

    <p>
        AS the topic mentioned above "ID card & Admit card generations" is website that is developed to help in managing the id card and admit card generations.
            It will take information from students and it generate id cards & admit card. Students have to register and then they have to logged in , they redirct to page 
            of dasboard where the find option of profile where they have to fill the neccessary details and also it is editable and then they see there id card and admit card.
            It will help to maintain the records of students and also generate the Ids and Admit. This process is Athentic. <br><br> The features are :- <br><br>
            1. It will generaate ID cards and Admit card  according to user information. <br>
            2. Admin will check the information is correct or not. <br>
            3. IF it is correct then Id card and Admit card will generate.<br>
            4. Students can see their own ID card & admit card generate by admin. <br>
            5. Students can edit their information in profile page.


    <p>
</div>

<?php include('footer.php'); ?>
