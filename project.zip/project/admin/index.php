<?php include('../connection/connect.php');
session_start();
?>

<?php 

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

     $suser= $_SESSION['admin_user'];
     $spass = $_SESSION['admin_pass'];
     $sgroup = $_SESSION['MM_UserGroup_admin'];

     $sql = mysqli_query($conn,"SELECT * FROM `admin` WHERE username = '$suser' AND pass = '$spass'");
     $row= mysqli_fetch_array($sql);
    

    if((!isset($suser)) || (!isset($spass)) || (!$row))
    {
        echo " <script>alert('Something went wrong.')</script>";
        echo " <script>location='../admin-login.php' </script>";
    }
?>

<?php include('header.php'); ?>





<div class="bg2">
    <div class="description-section">
        <h1 class="text-center">Welcome Admin</h1>
    
        <h3 class="text-center"><a class="admin-links" href="select-details.php?details=allot-id">Allot Id Card</a></h3>
        <h3 class="text-center"><a class="admin-links" href="select-details.php?details=alloted-list">Id Card Alloted List</a></h3>

        <br>

        <h3 class="text-center"><a class="admin-links" href="select-details.php?details=allot-admit">Allot Admit Card</a></h3>
        <h3 class="text-center"><a class="admin-links" href="select-details.php?details=alloted-admit-list">Admit Card Alloted List</a></h3>
        <br>

        <h3 class="text-center"><a class="admin-links" href="notice.php">Add Notice</a></h3>

        <br>

        <h3 class="text-center"><a class="admin-links" href="view-feedback.php">View Queries</a></h3>

    </div>

</div>



<?php include('footer.php'); ?>
<??>
