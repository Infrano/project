<?php include('../connection/connect.php');
session_start();
?>

<?php 

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

     $semail= $_SESSION['student_email'];
     $spass = $_SESSION['student_pass'];
     $sgroup = $_SESSION['MM_UserGroup_students'];

     $sql = mysqli_query($conn,"SELECT * FROM `student_details` WHERE email = '$semail' AND pass = '$spass' ");
     $row= mysqli_fetch_array($sql);
    

    if((!isset($semail)) || (!isset($spass)) || (!$row))
    {
        echo " <script>alert('Something went wrong.')</script>";
        echo " <script>location='../login.php' </script>";
    }

error_reporting(0);

$id = $_GET['id'];

$statusMsg = '';



if(isset($_POST["submit"]) && !empty($_FILES["file"]["name"])){

    $updated_id = $_POST['updated_id'];

    // File upload path
    $targetDir = "../student_img/";
    $fileName = basename($_FILES["file"]["name"]);
    $file_ext = strtolower(pathinfo($fileName ,PATHINFO_EXTENSION));
    $randName = md5(rand() * time());
    $new_name = $randName. '.' .$file_ext;
    rename( $fileName, $new_name) ;
    
    $targetFilePath = $targetDir . $new_name;
    $fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);

    
    $thumb='student_img/' . $new_name;

    // Allow certain file formats
    $allowTypes = array('jpg','png','jpeg');
    if(in_array($fileType, $allowTypes)){
        // Upload file to server
        if(move_uploaded_file($_FILES["file"]["tmp_name"], $targetFilePath)){
            // Insert image file name into database
            $insert = "UPDATE `student_details` SET `image`='$thumb' WHERE id = '$updated_id' ";
		    mysqli_query($conn,$insert);
        
            if($insert){
                $statusMsg = "The image has been uploaded successfully.";
            }else{
                $statusMsg = "File upload failed, please try again.";
            } 
        }else{
            $statusMsg = "Sorry, there was an error uploading your file.";
        }
    }else{
        $statusMsg = 'Sorry, only JPG, JPEG, PNG are allowed to upload.';
    }

    // Display status message
echo "<script>alert('$statusMsg')</script> ";
echo "<script>location='student-index.php'</script> ";
}




$sql = mysqli_query($conn,"SELECT * FROM `student_details` WHERE id = '$id' ");
$row = mysqli_fetch_array($sql);



?>



<!DOCTYPE html>
<html lang="en">
<head>
<title>Student Details</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../css/student.css">

</head>
<body>


<!-- navbar -->
<div class="navbar">
  <a href="#" class="logo"><img src="img/Logo.png" alt="" width="40" ></a>
  <a href="index.php" class="logo-text">TECHNO INDIA</a>
  
  <a  href="logout.php" class="right" onclick="return confirm('Are you sure?')">Logout</a>
  <a href="student-idcard.php?id=<?php echo $row['id']; ?>"  class="right">View Id Card</a>
  <a href="admit-card.php?id=<?php echo $row['id']; ?>"  class="right">View Admit Card</a>
  
  <a href="student-index.php" class="right">Home</a>
</div>
<!-- navbar -->



<h1 class="text-center" style="color: #026ba1;font-size:40px;">Welcome <?php echo $row['name']; ?></h1>

<div class="description-section">
    
    <div class="id-section" style="background: #f1f5fa;">

                <div style="margin: auto;text-align: center;">
                    <img src="img/Logo.png" style="width: 150px;" alt="">
                </div>


        <div style="display: flex;padding: 50px;">
            <div style="width: 70%;">
            
            <form action="<?php echo $editFormAction;?>" method="post" enctype="multipart/form-data">

                        <input type="hidden" value="<?php echo $id ?>" name="updated_id">
                Select Image to Upload ( Preferred size: 300 X 300 px ):  <br> <br>
                <input type="file" name="file" required> <br> <br>
                <input type="submit"  class="btn" name="submit" value="Upload">
            </form>
                

               
            </div>

            <div style="width: 30%; margin: auto;text-align: center;">

            <?php if($row['image']){ ?>

                <img src="../<?php echo $row['image']; ?>" style="max-width:100%;" alt="">

            <?php }else{ ?>

                <img src="../img/blank.webp" width="350px" alt="">
            <?php } ?>

            </div>

        </div>


    </div>
</div>





<?php include('../footer.php'); ?>
