<?php include('../connection/connect.php');

$id=$_GET['id'];

$sql = mysqli_query($conn,"DELETE FROM `notice` WHERE id = '$id'");

echo "<script>location='notice.php'</script>";


?>

