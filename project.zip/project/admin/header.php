<!DOCTYPE html>
<html lang="en">
<head>
<title>Admin</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../css/student.css">

<style>

.bg2{
    background-image: url('../img/bg.jpg');
    background-repeat: no-repeat;
    background-size: cover;
    padding: 60px 180px;
}

.admin-links{
    color: #5e1a8b;
    border: 2px solid #5e1a8b;
    padding: 10px 30px;
    width: 90%;
    border-radius: 4px;
    margin: 20px;
    text-decoration: none;
    display: block;
}

.admin-links:hover{
    color: #7e28b8;
    border-color: #7e28b8;
}
</style>

</head>
<body>


<!-- navbar -->
<div class="navbar">
  <a href="#" class="logo"><img src="img/Logo.png" alt="" width="40" ></a>
  <a href="index.php" class="logo-text">Techno College of Engineering Agartala</a>
  
  <a  href="logout.php" class="right" onclick="return confirm('Are you sure?')">Logout</a>
  <!--
  <a href="student-idcard.php?id=<?php echo $row['id']; ?>"  class="right">View Id Card</a>
  <a href="admit-card.php?id=<?php echo $row['id']; ?>"  class="right">View Admit Card</a>
-->
  <a href="index.php" class="right">Home</a>
</div>
<!-- navbar -->