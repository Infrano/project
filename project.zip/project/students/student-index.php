<?php include('../connection/connect.php'); 
session_start();
?>


<?php

    error_reporting(0);

     $semail= $_SESSION['student_email'];
     $spass = $_SESSION['student_pass'];
     $sgroup = $_SESSION['MM_UserGroup_students'];

     $sql = mysqli_query($conn,"SELECT * FROM `student_details` WHERE email = '$semail' AND pass = '$spass' ");
     $row= mysqli_fetch_array($sql);
    

    if((!isset($semail)) || (!isset($spass)) || (!$row))
    {
        echo " <script>alert('Something went wrong.')</script>";
        echo " <script>location='../login.php' </script>";
    }

?>





<!DOCTYPE html>
<html lang="en">
<head>
<title>Student Details</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../css/student.css">

</head>
<body>


<!-- navbar -->
<div class="navbar">
  <a href="#" class="logo"><img src="img/Logo.png" alt="" width="40" ></a>
  <a href="student-index.php" class="logo-text">Techno College of Engineering Agartala</a>
  
  <a  href="logout.php" class="right" onclick="return confirm('Are you sure?')">Logout</a>
  <a href="student-idcard.php?id=<?php echo $row['id']; ?>"  class="right">View Id Card</a>
  <a href="admit-card.php?id=<?php echo $row['id']; ?>"  class="right">View Admit Card</a>
  
  <a href="student-index.php" class="right">Home</a>
</div>
<!-- navbar -->



<h1 class="text-center" style="color: #026ba1;font-size:40px;">Welcome <?php echo $row['name']; ?></h1>

<div class="description-section">
    
    <div class="id-section" style="background: #f1f5fa;">

                <div style="margin: auto;text-align: center;">
                    <img src="img/Logo.png" style="width: 150px;" alt="">
                </div>


        <div style="display: flex;padding: 50px;">
            <div style="width: 70%;">

                <?php 

                $dob = $row['dob'];
                
                $dob_converted = date('d / m / Y', strtotime($dob));
                
                ?>
                <h4><b><span>STUDENT ID :</span> &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;    <?php if($row['student_id']) {echo $row['student_id'];}  ?></b></h4>
                <h4><b>STUDENT NAME :&nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  <?php echo $row['name']; ?></b></h4>
                <h4><b>FATHER'S NAME :&nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  <?php echo $row['father_name']; ?></b></h4>
                <h4><b>MOTHER'S NAME : &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;  <?php echo $row['mother_name']; ?></b></h4>
                <h4><b>DATE OF BIRTH :&nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;   <?php echo $dob_converted ; ?></b></h4>
                <h4><b>BLOOD GROUP :&nbsp;  &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;   <?php if($row['blood_group']) {echo $row['blood_group'];}  ?></b></h4>
                <h4><b>PHONE Number :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php echo $row['contact']; ?></b></h4>
                <h4><b>E-MAIL :&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php echo $row['email']; ?></b></h4>
                <h4><b>COURSE :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  <?php echo $row['course']; ?></b></h4>
                <h4><b>BRANCH :&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp; <?php echo $row['branch']; ?></b></h4>
                <h4><b>SEMESTER ADMITTED :&nbsp;&nbsp; <?php echo $row['sem_admitted']; ?></b></h4>
                <h4><b>CURRENT SEMESTER :&nbsp;&nbsp;&nbsp; <?php echo $row['curr_sem']; ?></b></h4>
                <h4><b>TU ROLL :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  <?php echo $row['tu_roll']; ?></b></h4>
                <h4><b>TU REG NO :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  <?php echo $row['tu_reg']; ?></b></h4>
                <h4><b>REG YEAR :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  <?php echo $row['reg_year']; ?></b></h4>
                <h4><b>ADDRESS :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  <?php echo $row['address']; ?></b></h4>
                
                <br><br>
                <div>
                    <a class="btn text-center" href="edit-student-details.php?id=<?php echo $row['id']; ?>">Edit Details</a>
                </div>
               
            </div>

            <div style="width: 30%; margin: auto;text-align: center;">

            <?php if($row['image']){  ?>

                <img src="../<?php echo $row['image'] ?>" style="max-width:100%;border-radius:4px;" alt="">
            
            <?php }else{?>

                <img src="img/blank.webp" width="350px" alt="">

            <?php  } ?>

                <br><br>
                <div class="text-center">
                    <a class="btn text-center" href="change-image.php?id=<?php echo $row['id']; ?>">Change Image</a>
                </div>

            </div>

        </div>


    </div>
</div>




<?php include('../footer.php'); ?>