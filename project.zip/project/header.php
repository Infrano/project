<!DOCTYPE html>
<html lang="en">
<head>
<title>Page Title</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/style2.css">
</head>
<body>


<!-- navbar -->
<div class="navbar">
  <a href="#" class="logo"><img src="img/Logo.png" alt="" width="40" ></a>
  <a href="index.php" class="logo-text">Techno College of Engineering Agartala</a>

  <a href="index.php" >Home</a>

  <a href="admin-login.php" >Admin</a>
  <a href="registration.php" >Student Registration</a>
  <a href="login.php" >Student Login</a>
  
  
  
</div>
<!-- navbar -->