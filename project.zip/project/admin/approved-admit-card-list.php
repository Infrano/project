<?php include('../connection/connect.php');
session_start();
?>

<?php 

error_reporting(0);

 $type = $_GET['type'];
 $branch = $_GET['branch'];
 $sem = $_GET['sem'];

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

     $suser= $_SESSION['admin_user'];
     $spass = $_SESSION['admin_pass'];
     $sgroup = $_SESSION['MM_UserGroup_admin'];

     $sql = mysqli_query($conn,"SELECT * FROM `admin` WHERE username = '$suser' AND pass = '$spass'");
     $row= mysqli_fetch_array($sql);
    

    if((!isset($suser)) || (!isset($spass)) || (!$row))
    {
        echo " <script>alert('Something went wrong.')</script>";
        echo " <script>location='../admin-login.php' </script>";
    }
?>

<?php
                if(isset($_POST['submit'])){

                    if(!empty($_POST['check_list'])) {
                        // Counting number of checked checkboxes.
                        $checked_count = count($_POST['check_list']);
                        // echo "You have selected following ".$checked_count." option(s): <br/>";
                        // Loop to store and display values of individual checked checkbox.
                        foreach($_POST['check_list'] as $selected) {

                        // echo "<p>".$selected ."</p>";

                        $update_sql = mysqli_query($conn,"UPDATE `student_details` SET `admit_status`= 0 WHERE id='$selected'");

                        }
                        
                        echo "<script>alert('Successfully Disapproved! Go to Allot Admit Card')</script>";
                        echo "<script>location='index.php'</script>";
                     
                    }
                    else{
                        echo "<script>alert('Please select atleast one student.')</script>";
                        
                    }

                }
            ?>

<?php include('header.php'); ?>

<style>
    table {
    border-collapse: collapse;
    width: 100%;
    }

    th, td {
    text-align: center;
    padding: 8px;
    border: 1px solid silver;
    }

    tr:nth-child(even) {
    background-color: #f0ffff;
    }
</style>

<?php

$sql_list = mysqli_query($conn,"SELECT * FROM `student_details` WHERE curr_sem='$sem' AND branch='$branch' AND admit_status = 1 ");
$row_list = mysqli_fetch_array($sql_list);

?>


<div class="bg2">
    <div class="description-section">
        <h1 class="text-center">Approved Admit Card List</h1>

        <?php if($row_list){ ?>
        <h4 class="text-center">Branch : <span style="color: #d63f3f;"><?php echo $row_list['branch'];?></span>  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Semester : <span style="color: #1f5fd0;"><?php echo $row_list['curr_sem'];?></span></h4>
       

        <form action="<?php echo $editFormAction;?>" method="post">

        <!-- <center><input type="checkbox" onclick="toggle(this);" />Approve All<br /></center> -->

        <br>
           
            <table>
                <tr>
                    <th>Sl.</th>
                    <th>Name</th>
                    <th>Student ID</th>
                    <th>View Admit Card</th>
                    <th>Disaprove</th>
                </tr>

                <?php 

                

                $sl=1;
                
                do{
                
                ?>
                <tr>
                    <td><?php echo $sl; ?></td>
                    <td><?php echo $row_list['name']; ?></td>
                    <td><?php echo $row_list['student_id']; ?></td>
                    <td><a href="admit-card.php?id=<?php echo $row_list['id']; ?>" target="_blank" style="text-decoration:none;">View</a></td>
                    <td><input type="checkbox" name="check_list[]" value="<?php echo $row_list['id']; ?>"  /></td>
                </tr>

                <?php $sl++; }while($row_list = mysqli_fetch_array($sql_list)); ?>

            </table>

            <h5 style="color:red;">( N.B : To edit a student details, student must be sent to unapproved list. )</h5>

            <center style="margin-top:20px;"><input type="submit" class="btn" name="submit" Value="Submit"/></center>
           
            
        </form>

        <?php }else{ ?>
            <h4 class="text-center" style="color:silver;"> No students present </h4>
        <?php } ?>
    </div>

</div>

<script>
    function toggle(source) {
    var checkboxes = document.querySelectorAll('input[type="checkbox"]');
    for (var i = 0; i < checkboxes.length; i++) {
        if (checkboxes[i] != source)
            checkboxes[i].checked = source.checked;
    }
}
</script>


<?php include('../footer.php')?>
