<?php include('../connection/connect.php'); ?>


<?php 

$id = $_GET['id'];

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if(isset($_POST['submit'])){

    date_default_timezone_set('Asia/Kolkata');
    $date = date('d-m-y h:i:s');

    $update_id = mysqli_real_escape_string($conn,$_POST['update_id']);

    $salutation = mysqli_real_escape_string($conn,$_POST['salutation']);
    $name = mysqli_real_escape_string($conn,$_POST['name']);
    $fname = mysqli_real_escape_string($conn,$_POST['father_name']);
    $mname = mysqli_real_escape_string($conn,$_POST['mother_name']);
    $phone = mysqli_real_escape_string($conn,$_POST['phone']);
    $email = mysqli_real_escape_string($conn,$_POST['email']);
    $dob = mysqli_real_escape_string($conn,$_POST['dob']);
    $blood_group = mysqli_real_escape_string($conn,$_POST['blood_group']);
    $caste = mysqli_real_escape_string($conn,$_POST['caste']);   
    $s_id = mysqli_real_escape_string($conn,$_POST['student_id']);
    $tu_roll = mysqli_real_escape_string($conn,$_POST['tu_roll']);
    $tu_reg = mysqli_real_escape_string($conn,$_POST['tu_reg']);
    $reg_year = mysqli_real_escape_string($conn,$_POST['reg_year']);
    $year_admitted = mysqli_real_escape_string($conn,$_POST['year_admitted']);
    $course = mysqli_real_escape_string($conn,$_POST['course']);
    $branch = mysqli_real_escape_string($conn,$_POST['branch']);
    $sem_admited = mysqli_real_escape_string($conn,$_POST['sem_admitted']);
    $curr_sem = mysqli_real_escape_string($conn,$_POST['curr_sem']);
    $address = mysqli_real_escape_string($conn,$_POST['address']);
    $pass = mysqli_real_escape_string($conn,$_POST['pass']);

    $sql = mysqli_query($conn,"UPDATE `student_details` SET `date`='$date',`salutation`='$salutation',`name`='$name',`father_name`='$fname',`mother_name`='$mname',`contact`='$phone',`email`='$email',`dob`='$dob',`blood_group`='$blood_group',`caste`='$caste',`student_id`='$s_id',`tu_roll`='$tu_roll',`tu_reg`='$tu_reg',`reg_year`='$reg_year',`admition_yeaar`='$year_admitted',`course`='$course',`branch`='$branch',`sem_admitted`='$sem_admited',`curr_sem`='$curr_sem',`address`='$address',`pass`='$pass' WHERE id='$update_id'");



    echo "<script>alert('Update Successful')</script>";
    echo "<script>location='unapproved-list.php?type=allot-id&&branch=$branch&&sem=$curr_sem'</script>";

}


$sql_check = mysqli_query($conn,"SELECT * FROM `student_details` WHERE id = '$id' ");
$row_check = mysqli_fetch_array($sql_check);



?>

<?php include('header.php'); ?>
<style>
.form-control{
    margin: 15px 0;
}

</style>


<div class="bg">
    <div class="description-section">
        <div style="margin: auto; text-align: center;">
            <img src="img/logo.png"  alt="" style="max-width: 150px;">
        </div>
     
        <h2 class="text-center" style="color: silver;">Edit Details</h2>
               
                    <form action="<?php echo $editFormAction;?>" method="POST">

                    <input type="hidden" name="update_id" value="<?php echo $row_check['id'] ?>">

                        <div >
                            <div ><label>Student ID</label>
                                <input type="text" name="student_id" value="<?php echo $row_check['student_id'] ?>" placeholder="Student ID" class="form-control">
                            </div>

                            <div ><label>T.U Roll No.</label>
                              <input type="text" name="tu_roll" value="<?php echo $row_check['tu_roll'] ?>" placeholder="TU Roll No." class="form-control">
                            </div>

                            <div>
                              <label for="group"><label>Salutation: *</label></label>
                                  <select name="salutation" class="form-control" required>
                                  <option value="option">Choose an Option</option>
                                  <option value="Mr." <?php if($row_check['salutation'] == 'Mr.'){?> selected <?php } ?>>Mr.</option>
                                  <option value="Miss" <?php if($row_check['salutation'] == 'Miss'){?> selected <?php } ?>>Miss</option>
                                  <option value="Mrs." <?php if($row_check['salutation'] == 'Mrs.'){?> selected <?php } ?>>Mrs.</option>

                                  </select>
                              </div> 
                          

                            <div  >
                                <div ><label>Name *</label>
                                    <input type="text" name="name" value="<?php echo $row_check['name'] ?>"  placeholder="Enter your Name" class="form-control" required>
                                </div>
                            </div>

                            <div  >
                              <div ><label>Father Name *</label>
                                  <input type="text" name="father_name" value="<?php echo $row_check['father_name'] ?>" placeholder="Father Name" class="form-control" required>
                              </div>
                          </div>

                          <div  >
                            <div ><label>Mother Name *</label>
                                <input type="text" name="mother_name" placeholder="Mother Name" value="<?php echo $row_check['mother_name'] ?>" class="form-control" required>
                            </div>
                        </div>

                            <div  >
                                <div ><label>Phone Number *</label>
                                    <input type="text" name="phone" placeholder="Enter Phone Number" value="<?php echo $row_check['contact'] ?>" class="form-control" required maxlength="10">
                                    
                                </div>
                            </div>


                            <div  >
                                <div ><label>Email</label>
                                    <input type="email" name="email" value="<?php echo $row_check['email'] ?>" placeholder="Enter Email" class="form-control">
                                </div>
                            </div>
                            
                            

                            <div>        
                                <label for="birthday"><label>DOB *</label></label>
                                <input type="date" id="birthday" name="dob" value="<?php echo $row_check['dob'] ?>" class="form-control" required>
                            </div> 
                            </br>

                            <div>
                            <label for="group"><label>Blood Group *</label></label>
                                <select id="blood group" name="blood_group" class="form-control" required>
                                <option value="option">Choose Blood Group</option>
                                <option value="A+" <?php if($row_check['blood_group'] == 'A+'){?> selected <?php } ?> >A+</option>
                                <option value="B+" <?php if($row_check['blood_group'] == 'B+'){?> selected <?php } ?>>B+</option>
                                <option value="O+" <?php if($row_check['blood_group'] == 'O+'){?> selected <?php } ?>>O+</option>
                                <option value="AB+" <?php if($row_check['blood_group'] == 'AB+'){?> selected <?php } ?>>AB+</option>
                                <option value="AB-" <?php if($row_check['blood_group'] == 'AB-'){?> selected <?php } ?>>AB-</option>
                                <option value="O-" <?php if($row_check['blood_group'] == 'O-'){?> selected <?php } ?>>O-</option>
                                <option value="B-" <?php if($row_check['blood_group'] == 'B-'){?> selected <?php } ?>>B-</option>
                                <option value="A-" <?php if($row_check['blood_group'] == 'A-'){?> selected <?php } ?>>A-</option>
                                </select>
                            </div> 
                            </br>

                            <div>
                              <label for="group"><label>Caste *</label></label>
                                  <select name="caste" class="form-control" required>
                                    <option value="option">Choose an Option</option>
                                    <option value="SC" <?php if($row_check['caste'] == 'SC'){?> selected <?php } ?>>SC</option>
                                    <option value="ST" <?php if($row_check['caste'] == 'ST'){?> selected <?php } ?>>ST</option>
                                    <option value="OBC" <?php if($row_check['caste'] == 'OBC'){?> selected <?php } ?>>OBC</option>
                                  </select>
                              </div>

                            <div>
                                <div ><label>Registration No</label>
                                    <input type="text" name="tu_reg" placeholder="Enter University Registration Number" value="<?php echo $row_check['tu_reg'] ?>" class="form-control">
                              
                                </div>
                            </div>

                            <div>
                            <label for="year"><label>Registration Year</label></label>
                                <select name="reg_year" id="reg_yr" class="form-control">
                                <option value="option">Choose an Year</option>
                                <option value="2015-2016" <?php if($row_check['reg_year'] == '2015-2016'){?> selected <?php } ?>>2015-2016</option>
                                <option value="2016-2017" <?php if($row_check['reg_year'] == '2016-2017'){?> selected <?php } ?>>2016-2017</option>
                                <option value="2017-2018" <?php if($row_check['reg_year'] == '2017-2018'){?> selected <?php } ?>>2017-2018</option>
                                <option value="2018-2019" <?php if($row_check['reg_year'] == '2018-2019'){?> selected <?php } ?>>2018-2019</option>
                                <option value="2019-2020" <?php if($row_check['reg_year'] == '2019-2020'){?> selected <?php } ?>>2019-2020</option>
                                <option value="2020-2021" <?php if($row_check['reg_year'] == '2020-2021'){?> selected <?php } ?>>2020-2021</option>
                                <option value="2021-2022" <?php if($row_check['reg_year'] == '2021-2022'){?> selected <?php } ?>>2021-2022</option>
                                <option value="2022-2023" <?php if($row_check['reg_year'] == '2022-2023'){?> selected <?php } ?>>2022-2023</option>
                              
                                </select>
                            </div> </br>

                            <div>

                              <label for="section"><label>Course *</label></label>
                              
                              <select name="course" id="branch" class="form-control" required>
                                <option value="option">Choose an Option</option>
                                <option value="B.E" <?php if($row_check['course'] == 'B.E'){?> selected <?php } ?>>B.E</option>
                                <option value="B.TECH" <?php if($row_check['course'] == 'B.TECH'){?> selected <?php } ?>>B.TECH</option>
                                <option value="DIPLOMA" <?php if($row_check['course'] == 'DIPLOMA'){?> selected <?php } ?>>DIPLOMA</option>
                           
                              </select>

                            <label for="section"><label>Branch *</label></label>
                                <select name="branch" id="branch" class="form-control" required>
                                <option value="option">Choose an Option</option>
                                <option value="CSE" <?php if($row_check['branch'] == 'CSE'){?> selected <?php } ?>>CSE</option>
                                <option value="CE" <?php if($row_check['branch'] == 'CE'){?> selected <?php } ?>>CE</option>
                                
                                <option value="ME" <?php if($row_check['branch'] == 'ME'){?> selected <?php } ?>>ME</option>
                                <option value="EE" <?php if($row_check['branch'] == 'EE'){?> selected <?php } ?>>EE</option>
                                <option value="ECE" <?php if($row_check['branch'] == 'ECE'){?> selected <?php } ?>>ECE</option>
                                <option value="CEGA" <?php if($row_check['branch'] == 'CEGA'){?> selected <?php } ?>>CECA</option>
                                <option value="EECA" <?php if($row_check['branch'] == 'EECA'){?> selected <?php } ?>>EECA</option>
                                </select>

                              <label for="class">Semester Admitted *</label>
                              <select name="sem_admitted" id="semester" class="form-control" required>
                                <option value="option">Choose an Option</option>
                                <option value="1st" <?php if($row_check['sem_admitted'] == '1st'){?> selected <?php } ?>>1ST</option>
                                <option value="2nd" <?php if($row_check['sem_admitted'] == '2nd'){?> selected <?php } ?>>2ND</option>
                                <option value="3rd" <?php if($row_check['sem_admitted'] == '3rd'){?> selected <?php } ?>>3RD</option>
                                <option value="4th" <?php if($row_check['sem_admitted'] == '4th'){?> selected <?php } ?>>4TH</option>
                                <option value="5th" <?php if($row_check['sem_admitted'] == '5th'){?> selected <?php } ?>>5TH</option>
                                <option value="6th" <?php if($row_check['sem_admitted'] == '6th'){?> selected <?php } ?>>6TH</option>
                                <option value="7th" <?php if($row_check['sem_admitted'] == '7th'){?> selected <?php } ?>>7TH</option>
                                <option value="8th" <?php if($row_check['sem_admitted'] == '8th'){?> selected <?php } ?>>8TH</option>
                              </select>
                            
                            <label for="class">Current Semester *</label>
                                <select name="curr_sem" id="semester" class="form-control" required>
                                <option value="option">Choose an Option</option>
                                <option value="1st" <?php if($row_check['curr_sem'] == '1st'){?> selected <?php } ?>>1ST</option>
                                <option value="2nd" <?php if($row_check['curr_sem'] == '2nd'){?> selected <?php } ?>>2ND</option>
                                <option value="3rd" <?php if($row_check['curr_sem'] == '3rd'){?> selected <?php } ?>>3RD</option>
                                <option value="4th" <?php if($row_check['curr_sem'] == '4th'){?> selected <?php } ?>>4TH</option>
                                <option value="5th" <?php if($row_check['curr_sem'] == '5th'){?> selected <?php } ?>>5TH</option>
                                <option value="6th" <?php if($row_check['curr_sem'] == '6th'){?> selected <?php } ?>>6TH</option>
                                <option value="7th" <?php if($row_check['curr_sem'] == '7th'){?> selected <?php } ?>>7TH</option>
                                <option value="8th" <?php if($row_check['curr_sem'] == '8th'){?> selected <?php } ?>>8TH</option>
                                </select>
                            </div> </br>

                            <label for="class">Year Of Admission *</label>
                              <select name="year_admitted" id="semester" class="form-control" required>
                                <option value="option">Choose an Option</option>
                                <option value="2018" <?php if($row_check['admition_yeaar'] == '2018'){?> selected <?php } ?>>2018</option>
                                <option value="2019" <?php if($row_check['admition_yeaar'] == '2019'){?> selected <?php } ?>>2019</option>
                                <option value="2020" <?php if($row_check['admition_yeaar'] == '2020'){?> selected <?php } ?>>2020</option>
                                <option value="2021" <?php if($row_check['admition_yeaar'] == '2021'){?> selected <?php } ?>>2021</option>
                                <option value="2022" <?php if($row_check['admition_yeaar'] == '2022'){?> selected <?php } ?>>2022</option>

                              </select>

                            <div ><label>Address *</label>
                              <textarea class="form-control" name="address" type="text" id="" cols="20" rows="10" required>
                                <?php echo $row_check['address'] ?>
                              </textarea>
                            </div>

                            <div >
                                <div ><label>Password *</label>
                                    <input type="Password" name="pass" placeholder="Enter Password" value="<?php echo $row_check['pass'] ?>" class="form-control" required>
                            
                                </div>
                            </div> 

                            <div  >
                                <div >
                                    <button type="submit" class="btn" name="submit">Update Details</button>
                                </div>

                            </div>
                    
                        </div>


                    </form>

    </div>

</div>






<?php include('../footer.php'); ?>