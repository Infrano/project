-- phpMyAdmin SQL Dump
-- version 4.7.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 04, 2022 at 01:07 AM
-- Server version: 5.7.19
-- PHP Version: 7.1.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id_generator`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `date` varchar(200) NOT NULL,
  `role` varchar(200) NOT NULL,
  `username` text NOT NULL,
  `pass` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `date`, `role`, `username`, `pass`) VALUES
(1, '', 'ADMINISTRATOR', 'admin', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `email` varchar(200) DEFAULT NULL,
  `feedback` text,
  `date` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `email`, `feedback`, `date`) VALUES
(1, 'a@a.c', 'test\'s;', '02-07-22 08:33:36'),
(2, 'Testing\'s;', 'Testing\'s;', '03-07-22 08:41:39'),
(3, 'a@a.c', 'test2', '03-07-22 08:42:20');

-- --------------------------------------------------------

--
-- Table structure for table `student_details`
--

CREATE TABLE `student_details` (
  `id` int(11) NOT NULL,
  `date` varchar(200) DEFAULT NULL,
  `salutation` text,
  `name` text,
  `father_name` text,
  `mother_name` text,
  `contact` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `dob` varchar(200) DEFAULT NULL,
  `blood_group` varchar(200) DEFAULT NULL,
  `caste` varchar(200) DEFAULT NULL,
  `student_id` varchar(200) DEFAULT NULL,
  `tu_roll` varchar(200) DEFAULT NULL,
  `tu_reg` varchar(200) DEFAULT NULL,
  `reg_year` varchar(200) DEFAULT NULL,
  `admition_yeaar` varchar(200) DEFAULT NULL,
  `course` varchar(200) DEFAULT NULL,
  `branch` varchar(200) DEFAULT NULL,
  `sem_admitted` varchar(200) DEFAULT NULL,
  `curr_sem` varchar(200) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `pass` varchar(200) DEFAULT NULL,
  `id_status` int(11) DEFAULT NULL,
  `admit_status` int(11) DEFAULT NULL,
  `image` varchar(200) DEFAULT NULL,
  `valid_start` varchar(200) DEFAULT NULL,
  `valid_end` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_details`
--

INSERT INTO `student_details` (`id`, `date`, `salutation`, `name`, `father_name`, `mother_name`, `contact`, `email`, `dob`, `blood_group`, `caste`, `student_id`, `tu_roll`, `tu_reg`, `reg_year`, `admition_yeaar`, `course`, `branch`, `sem_admitted`, `curr_sem`, `address`, `pass`, `id_status`, `admit_status`, `image`, `valid_start`, `valid_end`) VALUES
(9, '02-07-22 07:30:28', 'Mr.', 'Joy Roy', 'Something23', 'Mother2', '1258963335', 'a@a.c23', '2022-07-01', 'A+', 'SC', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '                                                        Test                                                        ', 'Arnab@1997', NULL, NULL, 'student_img/e5afbff3cfa1dd12670fd3498a11c914.jpeg', NULL, NULL),
(12, '04-07-22 12:37:38', 'Mr.', 'Abhishek Basfore', 'Ganesh Basfore', 'Rupa Basfore', '8794206683', 'abhishekbasforebaid365@gmail.com', '1999-04-01', 'O+', 'SC', '2030401012', '49/CS/L/23/23', '011452', '2020-2021', '4th', 'B.TECH', 'CSE ', '3rd', '6th', 'Ashram Choumuhani, Agartala (W).\r\n', 'qwe123', 0, 0, NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_details`
--
ALTER TABLE `student_details`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `student_details`
--
ALTER TABLE `student_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
