<?php include('../connection/connect.php');
session_start();
?>

<?php 

$details = $_GET['details'];

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

     $suser= $_SESSION['admin_user'];
     $spass = $_SESSION['admin_pass'];
     $sgroup = $_SESSION['MM_UserGroup_admin'];

     $sql = mysqli_query($conn,"SELECT * FROM `admin` WHERE username = '$suser' AND pass = '$spass'");
     $row= mysqli_fetch_array($sql);
    

    if((!isset($suser)) || (!isset($spass)) || (!$row))
    {
        echo " <script>alert('Something went wrong.')</script>";
        echo " <script>location='../admin-login.php' </script>";
    }
?>


<?php 

if(isset($_POST['submit'])){

    $type = mysqli_real_escape_string($conn,$_POST['type']);
    $branch = mysqli_real_escape_string($conn,$_POST['branch']);
    $sem = mysqli_real_escape_string($conn,$_POST['sem']);

    if($type == 'allot-id'){
    
        echo "<script>location='unapproved-list.php?type=$type&&branch=$branch&&sem=$sem'</script>";

    }elseif($type == 'alloted-list'){
    
        echo "<script>location='approved-list.php?type=$type&&branch=$branch&&sem=$sem'</script>";
    
    }elseif($type == 'allot-admit'){

        echo "<script>location='unapproved-admit-card-list.php?type=$type&&branch=$branch&&sem=$sem'</script>";
    
    }elseif($type == 'alloted-admit-list'){

        echo "<script>location='approved-admit-card-list.php?type=$type&&branch=$branch&&sem=$sem'</script>";
    
    }

}


?>

<?php include('header.php'); ?>





<div class="bg2">
    <div class="description-section">
        <h1 class="text-center">Select Details</h1>
    
        <form action="select-details.php" method="POST">

        <input type="hidden" name="type" value="<?php echo $details; ?>" >
                       

                                <select name="branch" id="branch" class="form-control" required>
                                <option value="option">Choose Branch</option>
                                <option value="CSE">CSE</option>
                                <option value="CE">CE</option>
                                
                                <option value="ME">ME</option>
                                <option value="EE">EE</option>
                                <option value="ECE">ECE</option>
                                <option value="CECA">CECA</option>
                                <option value="EECA">EECA</option>
                                </select>

                            <br><br>


                            
                       
                                <select name="sem" id="semester" class="form-control" required>
                                <option value="option">Choose Semester</option>
                                <option value="1st">1ST</option>
                                <option value="2nd">2ND</option>
                                <option value="3rd">3RD</option>
                                <option value="4th">4TH</option>
                                <option value="5th">5TH</option>
                                <option value="6th">6TH</option>
                                <option value="7th">7TH</option>
                                <option value="8th">8TH</option>
                                </select>

                                <br><br>
                        



                            <div  >
                                <center >
                                    <button type="submit" class="btn" name="submit">View List</button>
                                </center>

                            </div>
               

                    </form>

    </div>

</div>








<?php include('../footer.php')?>
