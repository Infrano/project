<?php include('connection/connect.php'); ?>


<?php 

session_start();


$loginFormAction = $_SERVER['PHP_SELF'];
if (isset($_GET['accesscheck'])) {
  $_SESSION['PrevUrl'] = $_GET['accesscheck'];
}

if(isset($_POST['submit'])){

    date_default_timezone_set('Asia/Kolkata');
    $date = date('d-m-y h:i:s');

    $email = mysqli_real_escape_string($conn,$_POST['email']);
    $pass = mysqli_real_escape_string($conn,$_POST['pass']);


    $MM_fldUserAuthorization = "";
    $MM_redirectLoginSuccess = "student-index.php";
    $MM_redirectLoginFailed = "login.php";
    $MM_redirecttoReferrer = false;

    $sql = mysqli_query($conn,"SELECT * FROM `student_details` WHERE email = '$email' AND pass = '$pass' ");

    
    $loginFoundUser = mysqli_num_rows($sql);
    if ($loginFoundUser) {
        $loginStrGroup = "student";
        
        //declare two session variables and assign them
        $_SESSION['student_email'] = $email;
        $_SESSION['student_pass'] = $pass;
        $_SESSION['MM_UserGroup_students'] = $loginStrGroup;	      
        
        if (isset($_SESSION['PrevUrl']) && false) {

            $MM_redirectLoginSuccess = $_SESSION['PrevUrl'];

        }
            
        echo "<script>location='students/student-index.php';</script>";
    }
    else {

        echo "<script>alert('No student account found ! Please check details.');</script>";
        echo "<script>location='login.php';</script>";
    
    }

}
?>

<?php include('header.php'); ?>


<div class="bg">
    <div class="description-section">
        <div style="margin: auto; text-align: center;">
            <img src="img/logo.png"  alt="" style="max-width: 150px;">
        </div>
        <h1 class="text-center" style="color: #e2261d;"><i>WELCOME TO TCEA</i></h1>
        <h3 class="text-center" style="color: silver;">Sign into Student account</h3>
               
        <form action="login.php" method="POST">
            <div>
                <div>
                    <input type="email" name="email" placeholder="Enter Email"class="form-control" required>
                </div>

            </div>
            
            <div>
                <div>
                    <input type="Password" name="pass" placeholder="Enter Password" class="form-control" required>
                </div>

            </div>

            <div>
                    <button type="submit" class="btn" name="submit"> Login </button>
            </div>
            <br>
            <!-- <a href="#">Forgot password</a> -->
            <p>Don't have an account? <a href="registration.php"> Register here </a> </p>


        </form>

    </div>

</div>





<?php include('footer.php'); ?>