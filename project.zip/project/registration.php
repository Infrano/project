<?php include('connection/connect.php'); ?>


<?php 

if(isset($_POST['submit'])){

    date_default_timezone_set('Asia/Kolkata');
    $date = date('d-m-y h:i:s');

    $salutation = mysqli_real_escape_string($conn,$_POST['salutation']);
    $name = mysqli_real_escape_string($conn,$_POST['name']);
    $fname = mysqli_real_escape_string($conn,$_POST['father_name']);
    $mname = mysqli_real_escape_string($conn,$_POST['mother_name']);
    $phone = mysqli_real_escape_string($conn,$_POST['phone']);
    $email = mysqli_real_escape_string($conn,$_POST['email']);
    $dob = mysqli_real_escape_string($conn,$_POST['dob']);
    $blood_group = mysqli_real_escape_string($conn,$_POST['blood_group']);
    $caste = mysqli_real_escape_string($conn,$_POST['caste']);   
    $s_id = mysqli_real_escape_string($conn,$_POST['student_id']);
    $tu_roll = mysqli_real_escape_string($conn,$_POST['tu_roll']);
    $tu_reg = mysqli_real_escape_string($conn,$_POST['tu_reg']);
    $reg_year = mysqli_real_escape_string($conn,$_POST['reg_year']);
    $year_admitted = mysqli_real_escape_string($conn,$_POST['year_admitted']);
    $course = mysqli_real_escape_string($conn,$_POST['course']);
    $branch = mysqli_real_escape_string($conn,$_POST['branch']);
    $sem_admited = mysqli_real_escape_string($conn,$_POST['sem_admitted']);
    $curr_sem = mysqli_real_escape_string($conn,$_POST['curr_sem']);
    $address = mysqli_real_escape_string($conn,$_POST['address']);
    $pass = mysqli_real_escape_string($conn,$_POST['pass']);
    $id_status = 0;
    $admit_status = 0;


    $sql_check = mysqli_query($conn,"SELECT * FROM `student_details` WHERE email = '$email' AND pass = '$pass' ");
    $row_check = mysqli_fetch_array($sql_check);

    //Optional

    if($row_check['email'] == $email && $row_check['pass'] == $pass){
      echo"<script>alert('Student Already Exists')</script>";
    }else{

      $sql = mysqli_query($conn,"INSERT INTO `student_details`(`date`, `salutation`, `name`, `father_name`, `mother_name`, `contact`, `email`, `dob`, `blood_group`, `caste`, `student_id`, `tu_roll`, `tu_reg`, `reg_year`, `year_admitted`, `course`, `branch`, `sem_admitted`, `curr_sem`, `address`,`pass`,`id_status`, `admit_status`)
      VALUES ('$date','$salutation','$name','$fname','$mname','$phone','$email','$dob','$blood_group','$caste','$s_id','$tu_roll','$tu_reg','$reg_year','$year_admitted','$course','$branch ','$sem_admited','$curr_sem','$address','$pass','$id_status','$admit_status')");
  
      echo "<script>alert('Registration Complete. We are taking you to login page .')</script>";
      echo "<script>location='login.php'</script>";

    }

    // $sql = mysqli_query($conn,"INSERT INTO `student_details`(`date`, `salutation`, `name`, `father_name`, `mother_name`, `contact`, `email`, `dob`, `blood_group`, `caste`, `student_id`, `tu_roll`, `tu_reg`, `reg_year`, `admition_yeaar`, `course`, `branch`, `sem_admitted`, `curr_sem`, `address`,`pass`)
    // VALUES ('$date','$salutation','$name','$fname','$mname','$phone','$email','$dob','$blood_group','$caste','$s_id','$tu_roll','$tu_reg','$reg_year','$year_admitted','$course','$branch ','$sem_admited','$curr_sem','$address','$pass')");

    // echo "<script>alert('Registration Complete. We are taking you to login page .')</script>";
    // echo "<script>location='login.php'</script>";



}



?>

<?php include('header.php'); ?>


<div class="bg">
    <div class="description-section">
        <div style="margin: auto; text-align: center;">
            <img src="img/logo.png"  alt="" style="max-width: 150px;">
        </div>
        <h1 class="text-center" style="color: #e2261d;"><i>WELCOME TO TCEA</i></h1>
        <h3 class="text-center" style="color: silver;">Register Here</h3>
               
                    <form action="registration.php" method="POST">
                        <div >
                            <div ><label>Student ID *</label>
                                <input type="text" name="student_id" placeholder="Student ID" class="form-control">
                            </div>

                            <div ><label>T.U Roll No. *</label>
                              <input type="text" name="tu_roll" placeholder="TU Roll No." class="form-control">
                            </div>

                            <div>
                                <div ><label>Registration No *</label>
                                    <input type="text" name="tu_reg" placeholder="Enter University Registration Number" class="form-control">
                              
                                </div>
                            </div>

                            <div>
                            <label for="year"><label>Registration Year *</label></label>
                                <select name="reg_year" id="reg_yr" class="form-control">
                                <option value="option">Choose an Year</option>
                                <option value="2015-2016">2014-2015</option>
                                <option value="2015-2016">2015-2016</option>
                                <option value="2016-2017">2016-2017</option>
                                <option value="2017-2018">2017-2018</option>
                                <option value="2018-2019">2018-2019</option>
                                <option value="2019-2020">2019-2020</option>
                                <option value="2020-2021">2020-2021</option>
                                <option value="2021-2022">2021-2022</option>
                                <option value="2022-2023">2022-2023</option>
                                <option value="2023-2024">2023-2024</option>
                                <option value="2024-2025">2024-2025</option>
                                </select>
                            </div>

                            <div>
                              <label for="group"><label>Salutation: *</label></label>
                                  <select name="salutation" class="form-control" required>
                                  <option value="option">Choose an Option</option>
                                  <option value="Mr.">Mr.</option>
                                  <option value="Miss">Miss</option>
                                  <option value="Mrs.">Mrs.</option>

                                  </select>
                              </div> 
                          

                            <div  >
                                <div ><label>Name *</label>
                                    <input type="text" name="name"  placeholder="Enter your Name" class="form-control" required>
                                </div>
                            </div>

                            <div  >
                              <div ><label>Father Name *</label>
                                  <input type="text" name="father_name" placeholder="Father Name" class="form-control" required>
                              </div>
                          </div>

                          <div  >
                            <div ><label>Mother Name *</label>
                                <input type="text" name="mother_name" placeholder="Mother Name" class="form-control" required>
                            </div>
                        </div>

                            <div  >
                                <div ><label>Phone Number *</label>
                                    <input type="text" name="phone" placeholder="Enter Phone Number" class="form-control" required maxlength="10">
                                    
                                </div>
                            </div>
                                       

                            <div>        
                                <label for="birthday"><label>DOB *</label></label>
                                <input type="date" id="birthday" name="dob" class="form-control" required>
                            </div> 
                            </br>

                            <div>
                            <label for="group"><label>Blood Group *</label></label>
                                <select id="blood group" name="blood_group" class="form-control" required>
                                <option value="option">Choose Blood Group</option>
                                <option value="A+">A+</option>
                                <option value="B+">B+</option>
                                <option value="O+">O+</option>
                                <option value="AB+">AB+</option>
                                <option value="AB-">AB-</option>
                                <option value="O-">O-</option>
                                <option value="B-">B-</option>
                                <option value="A-">A-</option>
                                </select>
                            </div> 
                            </br>

                            <div>
                              <label for="group"><label>Caste *</label></label>
                                  <select name="caste"   class="form-control" required>
                                  <option value="option">Choose an Option</option>
                                  <option value="GENERAL">GENERAL</option>
                                  <option value="SC">SC</option>
                                  <option value="ST">ST</option>
                                  <option value="OBC">OBC</option>
                                  <option value="RM">RM</option>
                                  </select>
                              </div>

                            <div>

                              <label for="section"><label>Course *</label></label>
                              
                              <select name="course" id="branch" class="form-control" required>
                                <option value="option">-</option>
                                <option value="B.TECH">B.TECH</option>
                              </select>

                            <label for="section"><label>Branch *</label></label>
                                <select name="branch" id="branch" class="form-control" required>
                                <option value="option">Choose an Option</option>
                                <option value="CSE">CSE</option>
                                <option value="CE">CE</option>
                                <option value="ME">ME</option>
                                <option value="EE">EE</option>
                                <option value="ECE">ECE</option>
                                <option value="ECSE">ECSE</option>
                                <option value="EECA">EECA</option>
                                <option value="AMIA">AMIA</option>
                                </select>

                              <label for="class">Semester Admitted *</label>
                              <select name="sem_admitted" id="semester" class="form-control" required>
                                <option value="option">Choose an Option</option>
                                <option value="1st">1ST</option>
                                <option value="3rd">3RD</option>
                              </select>
                            
                            <label for="class">Current Semester *</label>
                                <select name="curr_sem" id="semester" class="form-control" required>
                                <option value="option">Choose an Option</option>
                                <option value="1st">1ST</option>
                                <option value="2nd">2ND</option>
                                <option value="3rd">3RD</option>
                                <option value="4th">4TH</option>
                                <option value="5th">5TH</option>
                                <option value="6th">6TH</option>
                                <option value="7th">7TH</option>
                                <option value="8th">8TH</option>
                                </select>
                            </div> </br>

                            <label for="class">Year Of Admission *</label>
                              <select name="year_admitted" id="semester" class="form-control" required>
                                <option value="option">Choose an Option</option>
                                <option value="2018">2014</option>
                                <option value="2018">2015</option>
                                <option value="2018">2016</option>
                                <option value="2018">2017</option>
                                <option value="2018">2018</option>
                                <option value="2019">2019</option>
                                <option value="2020">2020</option>
                                <option value="2021">2021</option>
                                <option value="2022">2022</option>
                                <option value="2018">2023</option>
                                <option value="2018">2024</option>
                                <option value="2018">2025</option>
                              </select>

                            <div ><label>Address *</label>
                              <textarea class="form-control" name="address" type="text" id="" cols="20" rows="10" required></textarea>
                            </div>

                            <div>
                                <div ><label>E-mail *</label>
                                    <input type="email" name="email" placeholder="Enter Email" class="form-control" required>
                                </div>
                            </div>

                            <div >
                                <div ><label>Password *</label>
                                    <input type="Password" name="pass" placeholder="Enter Password" class="form-control" required>
                            
                                </div>
                            </div> 

                            <div  >
                                <div >
                                    <button type="submit" class="btn" name="submit">Register</button>
                                </div>

                            </div>
                            <p>Already have an account? <a href="login.php">Login here</a> </p>
                        </div>


                    </form>

    </div>

</div>






<?php include('footer.php'); ?>