<?php include('../connection/connect.php'); 
session_start();
?>


<?php

    $id = $_GET['id'];

     $semail= $_SESSION['student_email'];
     $spass = $_SESSION['student_pass'];
     $sgroup = $_SESSION['MM_UserGroup_students'];

     $sql = mysqli_query($conn,"SELECT * FROM `student_details` WHERE email = '$semail' AND pass = '$spass' ");
     $row= mysqli_fetch_array($sql);
    

    if((!isset($semail)) || (!isset($spass)) || (!$row))
    {
        echo " <script>alert('Something went wrong.')</script>";
        echo " <script>location='../login.php' </script>";
    }



$sql = mysqli_query($conn,"SELECT * FROM `student_details` WHERE id = '$id' ");
$row = mysqli_fetch_array($sql);

if( $row['admit_status'] == 0 || $row['admit_status'] == '' ){

    echo "<script>alert('Admit Card not yet alloted , Please contact college for more details .')</script>";
    echo "<script>location='student-index.php'</script>";

}



?>

<!DOCTYPE html>

<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Student Admit Card</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="">
        <style>
           

            .text-center{
                text-align: center;
            }

            .id-section{
                background-image: url('img/bg-id.jpg');
                background-repeat: no-repeat;
                background-size: cover;
                background-position: center;
            }
        </style>
    </head>
    <body>
        <div style="border: 2px solid black ; margin: 20px; padding: 20px;">
            <div style="display: flex;">
                <div style="width: 15%;">
                    <div style="margin: auto;text-align: right;">
                        <img src="img/Logo.png" style="width: 120px;" alt="">

                        <br><br>
                        <h3>Sl No. &nbsp; ...................</h3>
                    </div>
                </div>
        
                <div class="text-center"  style="width: 65%;">
                    <div >
                        <h1 style="margin: 0;">Techo College of Engineering Agartala</h1>
                        <p style="color: #e2261d;"> ( A Degree Engineering College affiliated to Tripura University,approved by AICTE )</p>
                        <p>Maheshkhola, Anandanagar, Agartala, West Tripura</p>
                    </div>
                    <br>
                    <h1>ADMIT CARD</h1>
                </div>

                <div style="width: 20%;">
                  <div>

                  
                      <div style="border: 2px solid black; width: 250px; height: 250px;">

                      </div>
                  </div>
              </div>
            </div>
    
            <div style="padding: 30px 50px; font-size: 19px;">

              <p>
                To the &nbsp; <span style="padding:0 240px ; border-bottom: 1px dotted black;"> <?php echo $row['curr_sem'] ?> </span> Semester , Examination <span style="padding:0 250px ; border-bottom: 1px dotted black;"> </span>
              </p>
              <p>
                Name &nbsp; <span style="padding:0 550px ; border-bottom: 1px dotted black;"> <?php echo $row['name'] ?> </span>
              </p>
              <p>
                Branch &nbsp; <span style="padding:0 550px ; border-bottom: 1px dotted black;"> <?php echo $row['branch'] ?> </span>
              </p>
              <p>
                Tripura University Registration No. &nbsp; <span style="padding:0 220px ; border-bottom: 1px dotted black;"> <?php echo $row['tu_reg'] ?> </span> of <span style="padding:0 100px ; border-bottom: 1px dotted black;"> <?php echo $row['reg_year'] ?> </span>
              </p>
              <p>
                Roll  &nbsp; <span style="padding:0 530px ; border-bottom: 1px dotted black;"> <?php echo $row['tu_roll'] ?> </span>
              </p>
    

    
            </div>
    
            <div style="display: flex;padding: 40px 50px;">
                <div style="width: 33%;">
                    
                </div>
                <div style="width: 33%;">
                    
                </div>
    
                <div style="width: 33%;">
                    <div class="text-center">
                        <h4 style="margin-top: 20px;font-size: 20px;">Controller of Examination </h4>
                    </div>
                </div>
            </div>
        </div>


        
        
    </body>
</html>