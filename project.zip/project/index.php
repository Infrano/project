<?php include('connection/connect.php'); ?>


<?php 

if(isset($_POST['submit'])){

    date_default_timezone_set('Asia/Kolkata');
    $date = date('d-m-y h:i:s');


    $name = mysqli_real_escape_string($conn,$_POST['name']);
    $sid = mysqli_real_escape_string($conn,$_POST['sid']);
    $type = mysqli_real_escape_string($conn,$_POST['type']);
    $feedback = mysqli_real_escape_string($conn,$_POST['text']);


    $sql = mysqli_query($conn,"INSERT INTO `feedback`(`name`, `student_id`,`type`,`feedback`, `date`) VALUES ('$name','$sid','$type','$feedback','$date')");

    echo "<script>alert(' Thank You ! We have recived your query .')</script>";
    echo "<script>location='index.php'</script>";

}



?>
<?php include('header.php'); ?>

<!-- slideshow -->
<div>
    <img class="mySlides" src="img/pic1.jpg" style="width:100%">
    <img class="mySlides" src="img/pic3.jpg" style="width:100%">
    <img class="mySlides" src="img/pic2.jpg" style="width:100%">
</div>
<!-- slideshow -->


<div class="text-center about-section">
    <h1>About Us</h1>

    <p>Here you can Genarate your own Admit Card or ID Card. Hope you Enjoy.........</p>
</div>

<div >
<div style="margin:20px 250px;">
    <h3 style="background-color:silver;padding:10px;margin: 0;">Notice</h3>
    <marquee  direction = "up" behavior="scroll" scrollamount="4" style="min-height:120px;border:2px solid silver;" >
    <?php
            
            $sql_notice = mysqli_query($conn,"SELECT * FROM `notice` ORDER BY id DESC "); 
            $row_notice = mysqli_fetch_array($sql_notice);

            if($row_notice){

                $sl = 1;
            
                do{
            ?>
        <div style="padding:10px;"><?php echo $sl; ?>. <?php echo $row_notice['notice']; ?></div>
    
    <?php $sl++; }while($row_notice = mysqli_fetch_array($sql_notice)); } ?>
        
    </marquee>
</div>
</div>



<!-- Feedback -->
<div class="feedback-section">
    <h1 >Query Form</h1>
    
    <p >Write down details if your facing issue regarding your Admit Card or ID Card</p>

    <form action="index.php" method="POST">
        <div>
            <label for="email">Student ID</label> <br><br>
            <input type="text" class="form-control" id="" placeholder="Enter Student Id" name="sid" required>        
        </div>
        <br>

        <div>
            <label for="email">Name</label> <br><br>
            <input type="text" class="form-control" id="email" placeholder="Enter Name" name="name" required>        
        </div>
        <br>

        <div>
            <label for="group"><label>Select Query Type </label></label>
            <select id="" name="type" class="form-control" required>
            <option value="option">-</option>
            <option value="Admit Card">Admit Card</option>
            <option value="Id Card">Id Card</option>
            </select>
        </div> 
        </br>

        <div>
            <label for="comment">Query</label> <br><br>
            <textarea class="form-control" id="comment" name="text" placeholder="Write about your query" required></textarea>
            
        </div>
        <br>

        <button type="submit" class="btn btn-primary" name="submit" herf="index.php">Submit</button>
    </form>

</div>

<script>
    var myIndex = 0;
    carousel();
    
    function carousel() {
      var i;
      var x = document.getElementsByClassName("mySlides");
      for (i = 0; i < x.length; i++) {
        x[i].style.display = "none";  
      }
      myIndex++;
      if (myIndex > x.length) {myIndex = 1}    
      x[myIndex-1].style.display = "block";  
      setTimeout(carousel, 3000); // Change image every 2 seconds
    }
</script>
<?php include('footer.php'); ?>