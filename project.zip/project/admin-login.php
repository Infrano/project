<?php include('connection/connect.php'); ?>


<?php 

session_start();


$loginFormAction = $_SERVER['PHP_SELF'];
if (isset($_GET['accesscheck'])) {
  $_SESSION['PrevUrl'] = $_GET['accesscheck'];
}

if(isset($_POST['submit'])){

    date_default_timezone_set('Asia/Kolkata');
    $date = date('d-m-y h:i:s');

    $username = mysqli_real_escape_string($conn,$_POST['username']);
    $pass = mysqli_real_escape_string($conn,$_POST['pass']);

    $MM_redirectLoginSuccess = "index.php";
    $MM_redirectLoginFailed = "admin-login.php";


    $sql = mysqli_query($conn,"SELECT * FROM `admin` WHERE username = '$username' AND pass = '$pass' AND role='ADMINISTRATOR'");
    $loginFoundUser = mysqli_num_rows($sql);

    if ($loginFoundUser) {
        $loginStrGroup = "ADMINISTRATOR";
        
        //declare two session variables and assign them
        $_SESSION['admin_user'] = $username;
        $_SESSION['admin_pass'] = $pass;
        $_SESSION['MM_UserGroup_admin'] = $loginStrGroup;	      
        
        if (isset($_SESSION['PrevUrl']) && false) {

            $MM_redirectLoginSuccess = $_SESSION['PrevUrl'];

        }
            
        echo "<script>location='admin/index.php';</script>";
    }
    else {

        echo "<script>alert('Please check details.');</script>";
        echo "<script>location='admin-login.php';</script>";
    
    }

}
?>

<?php include('header.php'); ?>


<div class="bg">
    <div class="description-section">
        <div style="margin: auto; text-align: center;">
            <img src="img/logo.png"  alt="" style="max-width: 150px;">
        </div>
        <h1 class="text-center" style="color: #e2261d;"><i>WELCOME Admin</i></h1>
        <h3 class="text-center" style="color: silver;">Sign In</h3>
               
        <form action="admin-login.php" method="POST">
            <div>
                <div>
                    <input type="text" name="username" placeholder="Userame"class="form-control" required>
                </div>

            </div>
            
            <div>
                <div>
                    <input type="Password" name="pass" placeholder="Enter Password" class="form-control" required>
                </div>

            </div>

            <div>
                    <button type="submit" class="btn" name="submit"> Login</button>
            </div>
            <br>


        </form>

    </div>

</div>





<?php include('footer.php'); ?>