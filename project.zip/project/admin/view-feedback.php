<?php include('../connection/connect.php');
session_start();
?>

<?php 

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

     $suser= $_SESSION['admin_user'];
     $spass = $_SESSION['admin_pass'];
     $sgroup = $_SESSION['MM_UserGroup_admin'];

     $sql = mysqli_query($conn,"SELECT * FROM `admin` WHERE username = '$suser' AND pass = '$spass'");
     $row= mysqli_fetch_array($sql);
    

    if((!isset($suser)) || (!isset($spass)) || (!$row))
    {
        echo " <script>alert('Something went wrong.')</script>";
        echo " <script>location='../admin-login.php' </script>";
    }
?>

<?php include('header.php'); ?>

<style>

table {
  border-collapse: collapse;
  width: 100%;
}

th, td {
  text-align: left;
  padding: 8px;
  border: 1px solid silver;
}

tr:nth-child(even) {
  background-color: #f0ffff;
}
</style>





<div class="bg2" style="min-height:800px;">
    <div class="description-section">
        <h1 class="text-center"> Id Card Queries</h1>
    
        <table>
            <tr>
                <th>Sl.</th>
                <th>Name</th>
                <th>Student ID</th>
                <th>Query</th>
            </tr>

            <?php
            
            $sql_feedback = mysqli_query($conn,"SELECT * FROM `feedback` WHERE type='Id Card' ORDER BY id DESC"); 
            $row_feedback = mysqli_fetch_array($sql_feedback);

            if($row_feedback){

                $sl = 1;
            
                do{
            ?>

            <tr>
                <td><?php echo $sl; ?></td>
                <td><?php echo $row_feedback['name']; ?></td>
                <td><?php echo $row_feedback['student_id']; ?></td>
                <td><?php echo $row_feedback['feedback']; ?></td>
            </tr>

            <?php $sl++; }while($row_feedback = mysqli_fetch_array($sql_feedback)); } ?>

        </table>
    </div>

    <div class="description-section">
        <h1 class="text-center"> Admit Card Queries</h1>
    
        <table>
            <tr>
                <th>Sl.</th>
                <th>Name</th>
                <th>Student ID</th>
                <th>Query</th>
            </tr>

            <?php
            
            $sql_feedback = mysqli_query($conn,"SELECT * FROM `feedback` WHERE type='Admit Card' ORDER BY id DESC"); 
            $row_feedback = mysqli_fetch_array($sql_feedback);

            if($row_feedback){

                $sl = 1;
            
                do{
            ?>

            <tr>
                <td><?php echo $sl; ?></td>
                <td><?php echo $row_feedback['name']; ?></td>
                <td><?php echo $row_feedback['student_id']; ?></td>
                <td><?php echo $row_feedback['feedback']; ?></td>
            </tr>

            <?php $sl++; }while($row_feedback = mysqli_fetch_array($sql_feedback)); } ?>

        </table>
    </div>

</div>








<??>
