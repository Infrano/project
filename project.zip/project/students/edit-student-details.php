<?php include('../connection/connect.php');
session_start();
?>


<?php 

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

$semail= $_SESSION['student_email'];
$spass = $_SESSION['student_pass'];
$sgroup = $_SESSION['MM_UserGroup_students'];

$sql = mysqli_query($conn,"SELECT * FROM `student_details` WHERE email = '$semail' AND pass = '$spass' ");
$row= mysqli_fetch_array($sql);


if((!isset($semail)) || (!isset($spass)) || (!$row))
{
   echo " <script>alert('Something went wrong.')</script>";
   echo " <script>location='../login.php' </script>";
}

error_reporting(0);

$id = $_GET['id'];

if(isset($_POST['submit'])){

    date_default_timezone_set('Asia/Kolkata');
    $date = date('d-m-y h:i:s');

    $updated_id = mysqli_real_escape_string($conn,$_POST['updated_id']);

    $salutation = mysqli_real_escape_string($conn,$_POST['salutation']);
    $name = mysqli_real_escape_string($conn,$_POST['name']);
    $fname = mysqli_real_escape_string($conn,$_POST['father_name']);
    $mname = mysqli_real_escape_string($conn,$_POST['mother_name']);
    $phone = mysqli_real_escape_string($conn,$_POST['phone']);
    $email = mysqli_real_escape_string($conn,$_POST['email']);
    $dob = mysqli_real_escape_string($conn,$_POST['dob']);
    $blood_group = mysqli_real_escape_string($conn,$_POST['blood_group']);
    $caste = mysqli_real_escape_string($conn,$_POST['caste']);   

    $address = mysqli_real_escape_string($conn,$_POST['address']);
    $pass = mysqli_real_escape_string($conn,$_POST['pass']);

    $sql = mysqli_query($conn," UPDATE `student_details`SET `date`='$date',`salutation`='$salutation',`name`='$name',`father_name`='$fname',`mother_name`='$mname',`contact`='$phone',`email`='$email',`dob`='$dob',`blood_group`='$blood_group',`caste`='$caste',`address`='$address',`pass`='$pass' WHERE id = '$updated_id' ");

    echo "<script>alert('Record updated successfully')</script>";
    echo "<script>location='student-index.php'</script>";

}


$sql_check = mysqli_query($conn,"SELECT * FROM `student_details` WHERE id = '$id' ");
$row_check = mysqli_fetch_array($sql_check);



?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Student Details</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../css/student.css">

</head>
<body>


<!-- navbar -->
<div class="navbar">
  <a href="#" class="logo"><img src="img/Logo.png" alt="" width="40" ></a>
  <a href="index.php" class="logo-text">TECHNO INDIA</a>
  
  <a  href="logout.php" class="right" onclick="return confirm('Are you sure?')">Logout</a>
  <a href="student-idcard.php?id=<?php echo $row['id']; ?>"  class="right">View Id Card</a>
  <a href="admit-card.php?id=<?php echo $row['id']; ?>"  class="right">View Admit Card</a>
  
  <a href="student-index.php" class="right">Home</a>
</div>
<!-- navbar -->


<div class="bg">
    <div class="description-section">
        <div style="margin: auto; text-align: center;">
            <img src="img/logo.png"  alt="" style="max-width: 150px;">
        </div>

        <h2 class="text-center" style="color: silver;">Update Details</h2>
               
                    <form action="<?php echo $editFormAction;?>" method="POST">

                        <input type="hidden" name="updated_id" value="<?php echo $id ?>" >
                        <div >
                            

                            <div>
                              <label for="group"><label>Salutation: </label></label>
                                  <select name="salutation" class="form-control" required>
                                  <option value="option">Choose an Option</option>
                                  <option value="Mr." <?php if($row_check['salutation'] == 'Mr.'){?> selected <?php } ?>>Mr.</option>
                                  <option value="Miss" <?php if($row_check['salutation'] == 'Miss'){?> selected <?php } ?>>Miss</option>
                                  <option value="Mrs." <?php if($row_check['salutation'] == 'Mrs.'){?> selected <?php } ?>>Mrs.</option>

                                  </select>
                            </div> 

                            <br>
                          

                            <div>
                                <div ><label>Name </label>
                                    <input type="text" name="name" value="<?php echo $row_check['name'] ?>"  placeholder="Enter your Name" class="form-control" required>
                                </div>
                            </div>

                            <br>

                            <div>
                              <div ><label>Father Name </label>
                                  <input type="text" name="father_name" value="<?php echo $row_check['father_name'] ?>" placeholder="Father Name" class="form-control" required>
                              </div>
                            </div>

                            <br>

                            <div>
                                <div ><label>Mother Name </label>
                                    <input type="text" name="mother_name" placeholder="Mother Name" value="<?php echo $row_check['mother_name'] ?>" class="form-control" required>
                                </div>
                            </div>

                            <br>

                        <div ><label>Phone Number </label>
                            <input type="text" name="phone" placeholder="Enter Phone Number" value="<?php echo $row_check['contact'] ?>" class="form-control" required maxlength="10">
                            
                        </div>

                        <br>
                      


                        <div>
                            <div ><label>Email</label>
                                <input type="email" name="email" value="<?php echo $row_check['email'] ?>" placeholder="Enter Email" class="form-control">
                            </div>
                        </div>

                        <br>
                            
                            

                        <div>        
                            <label for="birthday"><label>DOB </label></label>
                            <input type="date" id="birthday" name="dob" value="<?php echo $row_check['dob'] ?>" class="form-control" required>
                        </div> 
                            </br>

                        <div>
                        <label for="group"><label>Blood Group </label></label>
                            <select id="blood group" name="blood_group" class="form-control" required>
                            <option value="option">Choose Blood Group</option>
                            <option value="A+" <?php if($row_check['blood_group'] == 'A+'){?> selected <?php } ?> >A+</option>
                            <option value="B+" <?php if($row_check['blood_group'] == 'B+'){?> selected <?php } ?>>B+</option>
                            <option value="O+" <?php if($row_check['blood_group'] == 'O+'){?> selected <?php } ?>>O+</option>
                            <option value="AB+" <?php if($row_check['blood_group'] == 'AB+'){?> selected <?php } ?>>AB+</option>
                            <option value="AB-" <?php if($row_check['blood_group'] == 'AB-'){?> selected <?php } ?>>AB-</option>
                            <option value="O-" <?php if($row_check['blood_group'] == 'O-'){?> selected <?php } ?>>O-</option>
                            <option value="B-" <?php if($row_check['blood_group'] == 'B-'){?> selected <?php } ?>>B-</option>
                            <option value="A-" <?php if($row_check['blood_group'] == 'A-'){?> selected <?php } ?>>A-</option>
                            </select>
                        </div> 
                        </br>

                        <div>
                            <label for="group"><label>Caste </label></label>
                                <select name="caste" class="form-control" required>
                                <option value="option">Choose an Option</option>
                                <option value="GENERAL" <?php if($row_check['caste'] == 'GENERAL'){?> selected <?php } ?>>GENERAL</option>
                                <option value="SC" <?php if($row_check['caste'] == 'SC'){?> selected <?php } ?>>SC</option>
                                <option value="ST" <?php if($row_check['caste'] == 'ST'){?> selected <?php } ?>>ST</option>
                                <option value="OBC" <?php if($row_check['caste'] == 'OBC'){?> selected <?php } ?>>OBC</option>
                                </select>
                            </div>
                            <br>


                        <div ><label>Address </label>
                            <textarea class="form-control" name="address" type="text" id="" cols="20" rows="10" required>
                            <?php echo $row_check['address'] ?>
                            </textarea>
                        </div>

                        <br>

                        <div >
                            <div ><label>Password *</label>
                                <input id="myInput" type="Password" name="pass" placeholder="Enter Password" value="<?php echo $row_check['pass'] ?>" class="form-control" required>
                                <br>
                                <input type="checkbox" onclick="myFunction()">Show Password
                            </div>
                        </div> 

                        <br>

                            <div  >
                                <div >
                                    <button type="submit" class="btn" name="submit">Update Details</button>
                                </div>

                            </div>
                    
                        </div>


                    </form>

                    <h4 style="color:red"> [ N.B : If Email or Password or both is updated , the user will be loged-out and has to re-login with updated details ]   </h4>

    </div>

</div>

<script>
function myFunction() {
  var x = document.getElementById("myInput");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
</script>





<?php include('../footer.php'); ?>