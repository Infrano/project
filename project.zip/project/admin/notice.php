<?php include('../connection/connect.php');
session_start();
?>

<?php 

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

     $suser= $_SESSION['admin_user'];
     $spass = $_SESSION['admin_pass'];
     $sgroup = $_SESSION['MM_UserGroup_admin'];

     $sql = mysqli_query($conn,"SELECT * FROM `admin` WHERE username = '$suser' AND pass = '$spass'");
     $row= mysqli_fetch_array($sql);
    

    if((!isset($suser)) || (!isset($spass)) || (!$row))
    {
        echo " <script>alert('Something went wrong.')</script>";
        echo " <script>location='../admin-login.php' </script>";
    }
?>

<?php 

if(isset($_POST['submit'])){

    date_default_timezone_set('Asia/Kolkata');
    $date = date('d-m-y h:i:s');


   
    $notice = mysqli_real_escape_string($conn,$_POST['notice']);


    $sql = mysqli_query($conn,"INSERT INTO `notice`(`date`, `notice`) VALUES ('$date','$notice')");

    echo "<script>alert(' Updated ')</script>";
    echo "<script>location='notice.php'</script>";

}



?>

<?php include('header.php'); ?>

<style>

table {
  border-collapse: collapse;
  width: 100%;
}

th, td {
  text-align: center;
  padding: 8px;
  border: 1px solid silver;
}

tr:nth-child(even) {
  background-color: #f0ffff;
}
</style>




<div class="bg2" style="min-height:800px;">
    <div class="description-section">
        <h1 class="text-center"> Add Notice</h1>
    
        <div class="feedback-section">
            

            <form action="notice.php" method="POST">
                

                <div>
                    <label for="comment">Notice</label> <br><br>
                    <textarea class="form-control" id="comment" name="notice"  required></textarea>
                    
                </div>
                <br>

                <button type="submit" class="btn btn-primary" name="submit" herf="index.php">Post</button>
            </form>

        </div>
    </div>
 

    <div class="description-section">
        <h1 class="text-center"> View Notice</h1>
    
        <table>
            <tr>
                <th>Sl.</th>
                <th>Notice</th>
                <th>Action</th>
            </tr>

            <?php
            
            $sql_feedback = mysqli_query($conn,"SELECT * FROM `notice` ORDER BY id DESC "); 
            $row_feedback = mysqli_fetch_array($sql_feedback);

            if($row_feedback){

                $sl = 1;
            
                do{
            ?>

            <tr>
                <td><?php echo $sl; ?></td>
                <td><?php echo $row_feedback['notice']; ?></td>
                <td><a style="text-decoration:none;" href="delete-notice.php?id=<?php echo $row_feedback['id']; ?>">Delete</a></td>
            </tr>

            <?php $sl++; }while($row_feedback = mysqli_fetch_array($sql_feedback)); } ?>

        </table>
    </div>

</div>








<?php include('../footer.php')?>
